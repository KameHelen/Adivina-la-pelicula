
import tkinter as tk
from tkinter import messagebox, ttk
from juego import JuegoAdivinar
from database import obtener_historial, obtener_ranking_global, insertar_usuario, obtener_usuario_por_nombre, obtener_peliculas_disney, crear_conexion
import random
import sqlite3

class InterfazJuego:
    def __init__(self, root):
        self.root = root
        self.root.title("Adivina la Película Disney - Maratón")
        self.root.geometry("600x500")
        # Colores y fuentes
        self.bg_color = "#f0e6f6"
        self.btn_color = "#ffcc00"
        self.btn_hover_color = "#ffd740"
        self.text_color = "#333333"
        self.title_color = "#cc3399"
        self.font_title = ("Arial", 16, "bold")
        self.font_subtitle = ("Arial", 12)
        self.font_points = ("Arial", 12, "bold")
        self.font_buttons = ("Arial", 10, "bold")

        self.root.configure(bg=self.bg_color)

        self.usuario_actual_id = None
        self.usuario_actual_nombre = ""
        self.juego = None
        self.puntuacion_total = 0
        self.peliculas_jugadas = []
        self.peliculas_disponibles = []

        self.style = ttk.Style()
        # Configurar estilo para botones ttk
        self.style.configure("TButton",
                             font=self.font_buttons,
                             background=self.btn_color,
                             foreground=self.text_color)
        self.style.map("TButton",
                       background=[("active", self.btn_hover_color)])

        self.mostrar_pantalla_inicio()

    def mostrar_pantalla_inicio(self):
        """Muestra la pantalla de inicio de sesión o registro."""
        self.limpiar_ventana()

        tk.Label(self.root, text="¡Bienvenido al Maratón Disney!", font=self.font_title, fg=self.title_color, bg=self.bg_color).pack(pady=30)

        tk.Label(self.root, text="Introduce tu nombre de usuario:", font=self.font_subtitle, fg=self.text_color, bg=self.bg_color).pack(pady=10)
        self.entry_nombre_inicio = tk.Entry(self.root, width=30, font=("Arial", 12), justify='center')
        self.entry_nombre_inicio.pack(pady=10)

        tk.Button(self.root, text="Iniciar Sesión / Registrarse", command=self.iniciar_registro, font=self.font_buttons, bg=self.btn_color, fg=self.text_color, activebackground=self.btn_hover_color, width=25).pack(pady=15)
        tk.Button(self.root, text="Ver Ranking Global", command=self.mostrar_ranking_inicio, font=self.font_buttons, bg=self.btn_color, fg=self.text_color, activebackground=self.btn_hover_color, width=25).pack(pady=5)

    def iniciar_registro(self):
        """Intenta iniciar sesión o registrar un nuevo usuario."""
        nombre = self.entry_nombre_inicio.get().strip()
        if not nombre:
            messagebox.showwarning("Nombre Vacío", "Por favor, introduce un nombre de usuario.")
            return

        conn = crear_conexion()
        if not conn:
            messagebox.showerror("Error", "No se pudo conectar a la base de datos.")
            return

        user_id = obtener_usuario_por_nombre(conn, nombre)
        conn.close() # Cerramos la conexión de búsqueda

        if user_id:
            # Usuario existe, iniciar sesión
            self.usuario_actual_id = user_id
            self.usuario_actual_nombre = nombre
            self.empezar_maraton()
        else:
            # Usuario no existe, intentar registrarlo
            conn = crear_conexion() # Reabrimos para la inserción
            if not conn:
                 messagebox.showerror("Error", "No se pudo conectar a la base de datos para registrarse.")
                 return
            try:
                user_id = insertar_usuario(conn, nombre)
                conn.close()
                if user_id:

                    self.usuario_actual_id = user_id
                    self.usuario_actual_nombre = nombre
                    self.empezar_maraton()
                else:

                    conn = crear_conexion()
                    if not conn:
                         messagebox.showerror("Error", "No se pudo conectar a la base de datos para iniciar sesión tras falla de registro.")
                         return
                    existing_user_id = obtener_usuario_por_nombre(conn, nombre)
                    conn.close()
                    if existing_user_id:
                        self.usuario_actual_id = existing_user_id
                        self.usuario_actual_nombre = nombre
                        self.empezar_maraton()
                    else:
                        messagebox.showerror("Error", f"Error inconsistente al iniciar sesión con '{nombre}'.")
            except sqlite3.IntegrityError:

                 conn.close()

                 conn = crear_conexion()
                 if not conn:
                     messagebox.showerror("Error", "No se pudo conectar a la base de datos para iniciar sesión tras error de registro.")
                     return
                 existing_user_id = obtener_usuario_por_nombre(conn, nombre)
                 conn.close()
                 if existing_user_id:
                     self.usuario_actual_id = existing_user_id
                     self.usuario_actual_nombre = nombre
                     self.empezar_maraton()
                 else:

                     messagebox.showerror("Error", f"Error inconsistente al iniciar sesión con '{nombre}' tras error de unicidad.")
            except Exception as e:

                 conn.close()
                 messagebox.showerror("Error", f"Error al registrar usuario '{nombre}': {e}")


    def empezar_maraton(self):
        """Inicia la maratón de películas."""
        # Cargar todas las películas de la base de datos
        conn = crear_conexion()
        if not conn:
            messagebox.showerror("Error", "No se pudo conectar a la base de datos.")
            return
        self.peliculas_disponibles = obtener_peliculas_disney(conn)
        conn.close()

        if len(self.peliculas_disponibles) < 5:
            messagebox.showerror("Error", "No hay suficientes películas Disney en la base de datos para una maratón de 5.")
            return

        # Reiniciar variables de la sesión
        self.puntuacion_total = 0
        self.peliculas_jugadas = []
        self.juego_actual = None
        self.jugar_siguiente_pelicula()

    def jugar_siguiente_pelicula(self):
        """Crea una nueva partida para la siguiente película aleatoria no jugada."""
        # Filtrar las películas que ya han sido jugadas en esta sesión
        peliculas_restantes = [p for p in self.peliculas_disponibles if p["id"] not in self.peliculas_jugadas]

        if not peliculas_restantes:
            # Se han jugado las 5 (o todas disponibles)
            messagebox.showinfo("Fin de la Maratón", f"¡Has completado la maratón! Puntuación total: {self.puntuacion_total}")
            self.mostrar_pantalla_principal()
            return

        # Elegir una película aleatoria de las restantes
        pelicula_elegida = random.choice(peliculas_restantes)
        self.peliculas_jugadas.append(pelicula_elegida["id"])

        self.juego_actual = JuegoAdivinar(self.usuario_actual_id, pelicula_elegida)
        self.juego_actual.nueva_partida(pelicula_elegida)

        self.mostrar_interfaz_juego()

    def mostrar_interfaz_juego(self):
        """Muestra la interfaz del juego para la película actual."""
        self.limpiar_ventana()

        tk.Label(self.root, text=f"¡A Jugar, {self.usuario_actual_nombre}!", font=self.font_title, fg=self.title_color, bg=self.bg_color).pack(pady=10)
        tk.Label(self.root, text=f"Película #{len(self.peliculas_jugadas)}: Adivina la película Disney", font=self.font_subtitle, fg=self.text_color, bg=self.bg_color).pack(pady=5)
        tk.Label(self.root, text=f"Puntuación Total: {self.puntuacion_total}", font=self.font_subtitle, fg=self.text_color, bg=self.bg_color).pack(pady=5)

        self.label_puntos = tk.Label(self.root, text=f"Puntos Película: {self.juego_actual.puntos_actuales}", font=self.font_points, fg=self.title_color, bg=self.bg_color)
        self.label_puntos.pack(pady=10)

        self.text_pistas = tk.Text(self.root, height=8, width=65, state=tk.DISABLED, bg="white", fg=self.text_color, font=("Arial", 10))
        self.text_pistas.pack(pady=10)

        self.entry_respuesta = tk.Entry(self.root, width=50, font=("Arial", 12), justify='center')
        self.entry_respuesta.pack(pady=10)
        self.entry_respuesta.bind('<Return>', lambda event: self.enviar_respuesta())

        self.boton_pista = tk.Button(self.root, text="Pedir Pista", command=self.obtener_pista, font=self.font_buttons, bg=self.btn_color, fg=self.text_color, activebackground=self.btn_hover_color, width=20)
        self.boton_pista.pack(pady=5)

        self.boton_enviar = tk.Button(self.root, text="Enviar Respuesta", command=self.enviar_respuesta, font=self.font_buttons, bg=self.btn_color, fg=self.text_color, activebackground=self.btn_hover_color, width=20)
        self.boton_enviar.pack(pady=5)

        # Botón para salir al menú principal
        self.boton_salir_juego = tk.Button(self.root, text="Salir al Menú", command=self.salir_al_menu, font=self.font_buttons, bg="#ff6666", fg="white", activebackground="#ff8585", width=20) # Rojo claro para salir
        self.boton_salir_juego.pack(pady=10)

        # --- Lógica para mostrar la primera pista automáticamente ---
        # Usamos `after` para asegurarnos de que la interfaz se haya actualizado antes de mostrar la pista
        self.root.after(100, self.mostrar_primera_pista)

    def salir_al_menu(self):
        """Finaliza la película actual y vuelve al menú principal."""
        self.finalizar_pelicula(acerto=False)
        # Volver al menú principal
        self.mostrar_pantalla_principal()

    def mostrar_primera_pista(self):
        """Muestra la primera pista automáticamente."""
        self.obtener_pista()

    def limpiar_ventana(self):
        """Limpia todos los widgets de la ventana principal."""
        for widget in self.root.winfo_children():
            widget.destroy()

    def actualizar_puntos(self):
        self.label_puntos.config(text=f"Puntos Película: {self.juego_actual.puntos_actuales}")

    def obtener_pista(self):
        resultado_pista = self.juego_actual.pedir_pista()

        if isinstance(resultado_pista, tuple):
            pista, puntos_restantes = resultado_pista
            # Actualizar la interfaz con la nueva pista y los puntos restados
            self.text_pistas.config(state=tk.NORMAL)
            self.text_pistas.insert(tk.END, f"- {pista} (-{puntos_restantes} puntos)\n")
            self.text_pistas.see(tk.END)
            self.text_pistas.config(state=tk.DISABLED)
            self.actualizar_puntos()

            if not self.juego_actual.hay_mas_pistas():
                self.boton_pista.config(state=tk.DISABLED, bg="#cccccc", fg="#666666")

                if self.juego_actual.puntos_actuales <= 0:
                    messagebox.showinfo("Sin Pistas y Sin Puntos", "Ya no tienes más pistas ni puntos. ¡Sigue intentando adivinar!")

        else:
            pista_error = resultado_pista
            messagebox.showwarning("Fin de las Pistas", pista_error)
            return

    def enviar_respuesta(self):
        if not self.juego_actual:
            messagebox.showwarning("Error", "No hay una partida activa.")
            return

        respuesta = self.entry_respuesta.get().strip()
        if not respuesta:
            messagebox.showwarning("Respuesta Vacía", "Por favor, introduce un título.")
            return

        if self.juego_actual.verificar_respuesta(respuesta):
            messagebox.showinfo("¡Correcto!",
                                f"¡Adivinaste! La respuesta era: {self.juego_actual.pelicula_objetivo['titulo']}. Puntos obtenidos: {self.juego_actual.puntos_actuales}")
            # Deshabilitar los botones de la interfaz actual inmediatamente para evitar interacción
            self.boton_enviar.config(state=tk.DISABLED, bg="#cccccc", fg="#666666")
            self.boton_pista.config(state=tk.DISABLED, bg="#cccccc", fg="#666666")
            self.boton_salir_juego.config(state=tk.DISABLED, bg="#cccccc", fg="#666666")
            # Guardamos la partida como finalizada
            self.finalizar_pelicula(True)
            # Usamos after para llamar a jugar_siguiente_pelicula después de que se cierre el messagebox
            # y se procese el resto de la interfaz actual
            self.root.after(100,
                            self.jugar_siguiente_pelicula)
        else:

            if not self.juego_actual.hay_mas_pistas() and self.juego_actual.puntos_actuales <= 0:
                messagebox.showinfo("Fin de la Película",
                                    f"Te has quedado sin puntos y sin pistas. La respuesta era: {self.juego_actual.pelicula_objetivo['titulo']}")

                self.boton_enviar.config(state=tk.DISABLED, bg="#cccccc", fg="#666666")
                self.boton_pista.config(state=tk.DISABLED, bg="#cccccc", fg="#666666")
                self.boton_salir_juego.config(state=tk.DISABLED, bg="#cccccc", fg="#666666")
                # Guardamos la partida como finalizada
                self.finalizar_pelicula(False)
                self.root.after(100, self.jugar_siguiente_pelicula)
            else:
                messagebox.showinfo("Incorrecto", "Respuesta incorrecta. Sigue intentando o pide una pista.")
                self.entry_respuesta.delete(0, tk.END)

    def finalizar_pelicula(self, acerto):
        """Maneja el final de una película individual."""
        # Añadimos un control para asegurarnos de que self.juego_actual exista
        if not self.juego_actual:
            print("Error: self.juego_actual no está definido en finalizar_pelicula.")
            return

        puntos_película = self.juego_actual.puntos_actuales
        if acerto:
            self.puntuacion_total += puntos_película
        self.juego_actual.finalizar_partida(self.puntuacion_total)

    def mostrar_pantalla_principal(self):
        """Vuelve a la pantalla principal del menú."""
        self.limpiar_ventana()

        tk.Label(self.root, text=f"¡Hola, {self.usuario_actual_nombre}!", font=self.font_title, fg=self.title_color, bg=self.bg_color).pack(pady=20)
        tk.Label(self.root, text="Menú Principal", font=self.font_subtitle, fg=self.text_color, bg=self.bg_color).pack(pady=10)

        self.boton_historial = tk.Button(self.root, text="Ver Mi Historial", command=self.mostrar_historial, font=self.font_buttons, bg=self.btn_color, fg=self.text_color, activebackground=self.btn_hover_color, width=25)
        self.boton_historial.pack(pady=10)

        self.boton_ranking = tk.Button(self.root, text="Ver Ranking Global", command=self.mostrar_ranking, font=self.font_buttons, bg=self.btn_color, fg=self.text_color, activebackground=self.btn_hover_color, width=25)
        self.boton_ranking.pack(pady=10)

        self.boton_salir_sesion = tk.Button(self.root, text="Cerrar Sesión", command=self.mostrar_pantalla_inicio, font=self.font_buttons, bg="#ff6666", fg="white", activebackground="#ff8585", width=25) # Rojo claro para salir
        self.boton_salir_sesion.pack(pady=20)

    def mostrar_historial(self):
        historial_ventana = tk.Toplevel(self.root)
        historial_ventana.title("Mi Historial de Partidas")
        historial_ventana.geometry("700x400")

        tree = ttk.Treeview(historial_ventana, columns=("Titulo", "Puntos Película", "Puntos Totales", "Acierto", "Fecha"), show="headings")
        tree.heading("Titulo", text="Película/Serie")
        tree.heading("Puntos Película", text="Puntos Película")
        tree.heading("Puntos Totales", text="Puntos Totales Sesión")
        tree.heading("Acierto", text="¿Acierto?")
        tree.heading("Fecha", text="Fecha")

        tree.column("Titulo", width=150)
        tree.column("Puntos Película", width=120)
        tree.column("Puntos Totales", width=140)
        tree.column("Acierto", width=80)
        tree.column("Fecha", width=150)

        scrollbar = ttk.Scrollbar(historial_ventana, orient=tk.VERTICAL, command=tree.yview)
        tree.configure(yscroll=scrollbar.set)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        tree.pack(fill=tk.BOTH, expand=True)

        conn = crear_conexion()
        if conn:
            historial_datos = obtener_historial(conn, self.usuario_actual_id)
            conn.close()
            for item in historial_datos:
                tree.insert("", tk.END, values=(item["titulo"], item["puntos_película"], item["puntos_totales"], item["acerto"], item["fecha"]))

    def mostrar_ranking_inicio(self):
        """Muestra el ranking desde la pantalla de inicio."""
        self.mostrar_ranking()

    def mostrar_ranking(self):
        ranking_ventana = tk.Toplevel(self.root)
        ranking_ventana.title("Ranking Global")
        ranking_ventana.geometry("500x400")
        ranking_ventana.configure(bg=self.bg_color) # Fondo consistente

        tk.Label(ranking_ventana, text="Top 10 Puntuaciones Totales", font=self.font_title, fg=self.title_color, bg=self.bg_color).pack(pady=10)

        tree = ttk.Treeview(ranking_ventana, columns=("Usuario", "Puntos", "Fecha"), show="headings")
        tree.heading("Usuario", text="Usuario")
        tree.heading("Puntos", text="Puntos Totales")
        tree.heading("Fecha", text="Fecha")

        tree.column("Usuario", width=150)
        tree.column("Puntos", width=100)
        tree.column("Fecha", width=150)

        scrollbar = ttk.Scrollbar(ranking_ventana, orient=tk.VERTICAL, command=tree.yview)
        tree.configure(yscroll=scrollbar.set)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        tree.pack(fill=tk.BOTH, expand=True)

        conn = crear_conexion()
        if conn:
            ranking_datos = obtener_ranking_global(conn)
            conn.close()
            for item in ranking_datos:
                tree.insert("", tk.END, values=(item["nombre"], item["puntos"], item["fecha"]))


# --- main.py ---
if __name__ == "__main__":
    root = tk.Tk()
    app = InterfazJuego(root)
    root.mainloop()
