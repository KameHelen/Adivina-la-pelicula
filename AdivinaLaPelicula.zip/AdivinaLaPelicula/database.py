
import sqlite3

DB_PATH = "peliculas_series.db"

def crear_conexion():
    """Crea una conexión a la base de datos."""
    conn = None
    try:
        conn = sqlite3.connect(DB_PATH) # Usamos sqlite3.connect
        print(f"Conexión a SQLite establecida: {DB_PATH}")
    except sqlite3.Error as e: # Cambiamos Error por sqlite3.Error
        print(f"Error al conectar a la base de datos: {e}")
    return conn

def crear_tablas(conn):
    """Crea las tablas si no existen."""
    try:
        cursor = conn.cursor()
        # Tabla de Usuarios
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS usuarios (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nombre TEXT UNIQUE NOT NULL
            );
        """)
        # Tabla de Películas
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS peliculas_series (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                titulo TEXT NOT NULL,
                pista1 TEXT,
                pista2 TEXT,
                pista3 TEXT,
                pista4 TEXT,
                pista5 TEXT,
                pista6 TEXT,
                pista7 TEXT,
                categoria TEXT DEFAULT 'Disney'
            );
        """)
        # Tabla de Historial
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS historial (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                usuario_id INTEGER NOT NULL,
                titulo_adivinado TEXT NOT NULL,
                puntos_finales_película INTEGER, -- Puntos obtenidos en la película específica
                puntos_totales_sesion INTEGER,  -- Puntos acumulados en la sesión completa
                acerto BOOLEAN NOT NULL,
                fecha DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (usuario_id) REFERENCES usuarios (id)
            );
        """)
        conn.commit()
        print("Tablas creadas o ya existían.")
    except sqlite3.Error as e: # Cambiamos Error por sqlite3.Error
        print(f"Error al crear las tablas: {e}")

def insertar_usuario(conn, nombre):
    """Inserta un nuevo usuario. Devuelve el ID si es exitoso, None si ya existe."""
    try:
        cursor = conn.cursor()
        cursor.execute("INSERT INTO usuarios (nombre) VALUES (?);", (nombre,))
        conn.commit()
        return cursor.lastrowid
    except sqlite3.IntegrityError:
        print(f"El usuario '{nombre}' ya existe.")
        return None
    except sqlite3.Error as e: # Cambiamos Error por sqlite3.Error
        print(f"Error al insertar usuario: {e}")
        return None

def obtener_usuario_por_nombre(conn, nombre):
    """Obtiene el ID de un usuario por su nombre. Devuelve None si no existe."""
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM usuarios WHERE nombre = ?;", (nombre,))
        row = cursor.fetchone()
        return row[0] if row else None
    except sqlite3.Error as e: # Cambiamos Error por sqlite3.Error
        print(f"Error al obtener usuario: {e}")
        return None

def insertar_pelicula_serie(conn, titulo, pistas):
    """Inserta una nueva película."""
    try:
        cursor = conn.cursor()

        while len(pistas) < 7:
            pistas.append(None)
        cursor.execute("""
            INSERT INTO peliculas_series (titulo, pista1, pista2, pista3, pista4, pista5, pista6, pista7, categoria)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Disney');
        """, (titulo, *pistas))
        conn.commit()
        print(f"Película/Serie '{titulo}' insertada correctamente.")
    except sqlite3.Error as e: # Cambiamos Error por sqlite3.Error
        print(f"Error al insertar película/serie: {e}")

def obtener_peliculas_disney(conn):
    """Obtiene todas las películas de la categoría Disney."""
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT id, titulo, pista1, pista2, pista3, pista4, pista5, pista6, pista7 FROM peliculas_series WHERE categoria = 'Disney';")
        rows = cursor.fetchall()
        peliculas = []
        for row in rows:
            # Filtrar las pistas que no son None
            pistas = [p for p in row[2:] if p is not None]
            peliculas.append({"id": row[0], "titulo": row[1], "pistas": pistas})
        return peliculas
    except sqlite3.Error as e: # Cambiamos Error por sqlite3.Error
        print(f"Error al obtener películas Disney: {e}")
        return []

def insertar_historial(conn, usuario_id, titulo_adivinado, puntos_finales_película, puntos_totales_sesion, acerto):
    """Inserta un registro en el historial."""
    try:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO historial (usuario_id, titulo_adivinado, puntos_finales_película, puntos_totales_sesion, acerto)
            VALUES (?, ?, ?, ?, ?);
        """, (usuario_id, titulo_adivinado, puntos_finales_película, puntos_totales_sesion, 1 if acerto else 0))
        conn.commit()
        print("Registro de historial insertado correctamente.")
    except sqlite3.Error as e: # Cambiamos Error por sqlite3.Error
        print(f"Error al insertar historial: {e}")

def obtener_historial(conn, usuario_id):
    """Obtiene el historial de un usuario específico."""
    try:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT h.titulo_adivinado, h.puntos_finales_película, h.puntos_totales_sesion, h.acerto, h.fecha
            FROM historial h
            WHERE h.usuario_id = ?
            ORDER BY h.fecha DESC;
        """, (usuario_id,))
        rows = cursor.fetchall()
        return [{"titulo": r[0], "puntos_película": r[1], "puntos_totales": r[2], "acerto": "Sí" if r[3] else "No", "fecha": r[4]} for r in rows]
    except sqlite3.Error as e: # Cambiamos Error por sqlite3.Error
        print(f"Error al obtener historial del usuario: {e}")
        return []

def obtener_ranking_global(conn, limite=10):
    """Obtiene el ranking global de mejores puntajes TOTALES."""
    try:
        cursor = conn.cursor()
        # Busca la mejor puntuación total por sesión de cada usuario
        cursor.execute("""
            SELECT u.nombre, MAX(h.puntos_totales_sesion) as max_puntos, h.fecha
            FROM historial h
            JOIN usuarios u ON h.usuario_id = u.id
            GROUP BY u.id
            ORDER BY max_puntos DESC, h.fecha ASC -- Ordena por puntos totales descendente, y por fecha ascendente para desempates
            LIMIT ?;
        """, (limite,))
        rows = cursor.fetchall()
        return [{"nombre": r[0], "puntos": r[1], "fecha": r[2]} for r in rows]
    except sqlite3.Error as e: # Cambiamos Error por sqlite3.Error
        print(f"Error al obtener ranking global: {e}")
        return []


# --- Inicialización ---
if __name__ == "__main__":
    conn = crear_conexion()
    if conn:
        crear_tablas(conn)
        peliculas_datos = {
            "Ratatouille": [
                "Un ser diminuto desafía las expectativas en un mundo de sabores.",
                "El aroma de la infancia guía una búsqueda imposible.",
                "Un oficio ancestral se ve cuestionado por una visión inesperada.",
                "La crítica más dura puede nacer del corazón más frágil.",
                "La cocina se convierte en un puente entre mundos opuestos.",
                "Un sueño compartido cobra vida entre fogones.",
                "La perfección culinaria nace de la imperfección humana."
            ],
            "El Rey León": [
                "Un ciclo eterno se rompe con la sombra de la traición.",
                "El eco de un rugido resuena en la sabana de la memoria.",
                "La responsabilidad del pasado pesa más que el cielo estrellado.",
                "Un joven corazón debe abandonar su refugio para encontrar su voz.",
                "El reino animal enfrenta su destino entre sombras y luz.",
                "Un nombre lleva el peso de un linaje olvidado.",
                "La danza de la vida se observa desde la melena de un león."
            ],
            "Coco": [
                "La música es el hilo que teje los recuerdos entre dos mundos.",
                "Una guitarra olvidada despierta ecos del pasado.",
                "Las flores de cempasúchil iluminan un camino prohibido.",
                "El verdadero legado se encuentra en los corazones que amamos.",
                "La memoria es el regalo más frágil y poderoso.",
                "Un viaje al inframundo revela secretos familiares.",
                "El nombre de un niño esconde una melodía prohibida."
            ],
            "Blancanieves y los siete enanitos": [
                "Un corazón puro encuentra refugio en la simplicidad.",
                "El espejo refleja verdades que hieren más que la espina.",
                "Siete extraños se convierten en familia en un bosque encantado.",
                "La belleza de la inocencia despierta envenenada por la envidia.",
                "Un sueño profundo espera el beso de la esperanza.",
                "La voz de la naturaleza advierte del peligro inminente.",
                "La pureza del nombre contrasta con el color del desdén."
            ],
            "El Planeta del Tesoro": [
                "Un mapa celestial conduce a un tesoro más allá de lo imaginable.",
                "Las velas de luz navegan por mares de estrellas.",
                "Un viejo lobo de mar oculta un secreto en su mirada.",
                "El tesoro más valioso no se mide en oro sideral.",
                "Un planeta cambia de forma como un recuerdo distorsionado.",
                "La lealtad se pone a prueba entre tormentas de energía.",
                "Un gato cósmico ronronea en la oscuridad del espacio."
            ]
        }

        for titulo, pistas in peliculas_datos.items():
            insertar_pelicula_serie(conn, titulo, pistas)
        conn.close()
