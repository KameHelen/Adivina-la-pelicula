
from database import obtener_peliculas_disney, insertar_historial, crear_conexion
import random

class JuegoAdivinar:
    def __init__(self, usuario_id, pelicula_objetivo):
        self.usuario_id = usuario_id
        self.pelicula_objetivo = pelicula_objetivo
        self.puntos_iniciales = 30
        self.puntos_actuales = self.puntos_iniciales
        self.pistas_usadas = 0
        self.max_pistas_posibles = 6
        self.max_pistas_guardadas = len(self.pelicula_objetivo["pistas"])
        self.max_pistas = min(self.max_pistas_posibles, self.max_pistas_guardadas)
        self.ha_adivinado = False
        self.ha_pedir_pista = False
        self.puntos_a_restar_internamente = [0, 2, 4, 6, 8, 10]

    def nueva_partida(self, pelicula_objetivo):
        """Reinicia la lógica para una nueva película objetivo."""
        self.pelicula_objetivo = pelicula_objetivo
        self.puntos_actuales = self.puntos_iniciales
        self.pistas_usadas = 0
        self.max_pistas_guardadas = len(self.pelicula_objetivo["pistas"])
        self.max_pistas = min(self.max_pistas_posibles, self.max_pistas_guardadas)
        self.ha_adivinado = False
        self.ha_pedir_pista = False
        return True

    def pedir_pista(self):
        """Devuelve la siguiente pista si es posible."""
        if self.pistas_usadas < self.max_pistas and self.pelicula_objetivo:
            puntos_a_restar_interno = self.puntos_a_restar_internamente[self.pistas_usadas]
            self.puntos_actuales -= puntos_a_restar_interno
            if self.puntos_actuales < 0:
                 self.puntos_actuales = 0

            # Obtener la pista de la lista guardada
            pista = self.pelicula_objetivo["pistas"][self.pistas_usadas]

            puntos_a_mostrar = puntos_a_restar_interno
            if self.pistas_usadas == 5: # Va a pedir la 6ª pista (índice 5)
                 puntos_a_mostrar = 10

            self.pistas_usadas += 1
            self.ha_pedir_pista = True
            return pista, puntos_a_mostrar
        else:
            return "No hay más pistas disponibles.", 0

    def verificar_respuesta(self, respuesta_usuario):
        """Verifica si la respuesta del usuario es correcta, permitiendo coincidencias parciales."""
        if not self.pelicula_objetivo:
            return False

        respuesta_limpia = respuesta_usuario.strip().lower()
        titulo_correcto = self.pelicula_objetivo["titulo"].lower()

        if respuesta_limpia in titulo_correcto or titulo_correcto in respuesta_limpia:
            self.ha_adivinado = True
            return True
        return False

    def finalizar_partida(self, puntos_totales_sesion):
        """Guarda el resultado de la partida en el historial."""
        if self.pelicula_objetivo:
            conn = crear_conexion()
            if conn:
                insertar_historial(conn, self.usuario_id, self.pelicula_objetivo["titulo"], self.puntos_actuales, puntos_totales_sesion, self.ha_adivinado)
                conn.close()

    def hay_mas_pistas(self):
        return self.pistas_usadas < self.max_pistas
