
from interfaz import InterfazJuego
import tkinter as tk

if __name__ == "__main__":
    root = tk.Tk()
    app = InterfazJuego(root)
    root.mainloop()
